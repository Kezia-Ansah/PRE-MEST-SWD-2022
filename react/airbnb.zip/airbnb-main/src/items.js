const items = [
  {
    image: "images/1.png",
    status: "SOLD OUT",
    star: "images/2.png",
    rating: "5.0",
    reviewCount: "(6)",
    title: "Life lessons with Katie Zaferes",
    cost: "From $136",
    person: " / person",
  },
  {
    image: "images/3.png",
    status: "ONLINE",
    star: "images/2.png",
    rating: "5.0",
    reviewCount: "(30)",
    title: "Learn wedding photography",
    cost: "From $125",
    person: " / person",
  },
  {
    image: "images/4.png",
    star: "images/2.png",
    rating: "4.8",
    reviewCount: "(2)",
    title: "Group Mountain Biking",
    cost: "From $50",
    person: " / person",
  },
];

export default items;
